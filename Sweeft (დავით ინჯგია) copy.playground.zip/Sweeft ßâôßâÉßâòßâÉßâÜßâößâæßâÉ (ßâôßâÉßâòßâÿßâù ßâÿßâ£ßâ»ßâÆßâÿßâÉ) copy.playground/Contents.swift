import UIKit
import Foundation
import Darwin



//1.     დაწერეთ ფუნქცია, რომელსაც გადაეცემა ტექსტი  და აბრუნებს პალინდრომია თუ არა. (პალინდრომი არის ტექსტი რომელიც ერთნაირად იკითხება ორივე მხრიდან).

func isPalindrome(text: String) -> Bool{
    if text == String(text.reversed()){
        return true
    }else{
        return false
    }
}
print("1)")
print("-------------------------------------")

print(isPalindrome(text: "ana"))

print("")


//2.     გვაქვს 1,5,10,20 და 50 თეთრიანი მონეტები. დაწერეთ ფუნქცია, რომელსაც გადაეცემა თანხა (თეთრებში) და აბრუნებს მონეტების მინიმალურ რაოდენობას, რომლითაც შეგვიძლია ეს თანხა დავახურდაოთ.


func minSplit(amount: Int) -> String {
    var value = amount
    let coins =  [1, 5, 10, 20, 50]
    var coinArray = [Int]()
    
    var i = coins.count - 1
    while( i >= 0){
        while (value >= coins[i]){
            value -= coins[i]
            coinArray.append(coins[i])
        }
        i -= 1
    }
    var counts = [Int: Int]()
    coinArray.forEach{ counts[$0] = (counts[$0] ?? 0) + 1 }
    
//    print(coinArray)
//    print(counts)
    return "არსებული თანხის \(amount) (თეთრის) დასახურდავებლად საჭიროა მინიმუმ \(counts) "
}

print("2)")
print("-------------------------------------")
print(minSplit(amount: 320))
print("")

//3.     მოცემულია მასივი, რომელიც შედგება მთელი რიცხვებისგან. დაწერეთ ფუნქცია რომელსაც გადაეცემა ეს მასივი და აბრუნებს მინიმალურ მთელ რიცხვს, რომელიც 0-ზე მეტია და ამ მასივში არ შედის. Int notContains(Int[] array);


let array = [1,2,3,5,7,8,12,14]


func notContains(array: [Int]) -> Int {
    let minValueNotInArray = Set(1...array.count).subtracting(Set(array)).min()!
    return minValueNotInArray
}

print("3)")
print("-------------------------------------")
print(notContains(array: array))
print("")




//4.     მოცემულია String რომელიც შედგება „(„ და „)“ ელემენტებისგან. დაწერეთ ფუნქცია რომელიც აბრუნებს ფრჩხილები არის თუ არა მათემატიკურად სწორად დასმული. მაგ: (()()) სწორი მიმდევრობაა,  ())() არასწორია

//Boolean isProperly(String sequence);
func isProperly(sequence: String) -> Bool{
    var value = sequence
    while true{
        if value.contains("()"){
           value = value.replacingOccurrences(of: "()", with: "")
        } else if value.contains("{}"){
           value = value.replacingOccurrences(of: "{}", with: "")
        }else if value.contains("[]"){
            value = value.replacingOccurrences(of: "[]", with: "")
        }else {
            return value.isEmpty
            
        }
    }
}
print("4)")
print("-------------------------------------")
let sequence = "{[()]}"
print("\(sequence)\(isProperly(sequence: sequence))")

let sequence1 = "())()"
print("\(sequence1)\(isProperly(sequence: sequence1))")

let sequence2 = "(()())"
print("\(sequence2)\(isProperly(sequence: sequence2))")
print("")



//5. გვაქვს n სართულიანი კიბე, ერთ მოქმედებაში შეგვიძლია ავიდეთ 1 ან 2 საფეხურით. დაწერეთ ფუნქცია რომელიც დაითვლის n სართულზე ასვლის ვარიანტების რაოდენობას. Int countVariants(Int stearsCount);


func countVariants(n: Int) -> Int {
    
    if n < 0 {
        return 0
    }else if n == 0 {
        return 1
    }else {
        return countVariants(n: n - 2) + countVariants(n: n - 1)
    }
    
    
}

print("5)")
print("-------------------------------------")
let n = 4
print("Total ways: \(countVariants(n: n))")
print("")


//6. დაწერეთ საკუთარი მონაცემთა სტრუქტურა, რომელიც საშუალებას მოგვცემს O(1) დროში წავშალოთ ელემენტი.

print("6)")
print("-------------------------------------")
extension Array where Element: Hashable {
    mutating func remove(values: [Element]) {
        let set = Set(values)
        removeAll { set.contains($0) }
    }
}

var array1 = [0, 1, 2, 3, 4, 5, 6]
var values = [1, 3, 5]
array1.remove(values: values)
print(array1)
